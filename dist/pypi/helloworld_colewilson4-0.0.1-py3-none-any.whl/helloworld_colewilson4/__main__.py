print('Hello, World!')

input()